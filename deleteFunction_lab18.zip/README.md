# serverless-api-delete
Codefellows 401 Javascript: Lab 18 - AWS: API, Dynamo and Lambda Overview - Delete Function
